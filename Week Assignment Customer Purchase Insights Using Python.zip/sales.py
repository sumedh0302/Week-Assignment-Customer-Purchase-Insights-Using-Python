import pandas as pd  # Import the pandas library for data manipulation

#  Load your CSV file
# Replace 'sales.csv' with the actual file path if it's somewhere else
data = pd.read_csv('sales.csv')  # Read the CSV file into a DataFrame called 'data'

#  Calculate Sales Amount if it's not already in the CSV
# Assuming your CSV has columns: 'Quantity' and 'Price'
if 'SalesAmount' not in data.columns:  # Check if 'SalesAmount' column exists
    data['SalesAmount'] = data['Quantity'] * data['Price']  # Create it by multiplying Quantity * Price

# Calculate Total Sales Amount
total_sales = data['SalesAmount'].sum()  # Sum all values in 'SalesAmount' column
print("Total Sales Amount:", total_sales)  # Print the total sales amount

# S Find Most Sold Product (by quantity)
most_sold_product = data.groupby('Product')['Quantity'].sum().idxmax()
# Explanation:
# 1. groupby('Product') groups rows by each product
# 2. ['Quantity'].sum() sums the quantity sold for each product
# 3. idxmax() returns the product with the highest total quantity sold
print("Most Sold Product:", most_sold_product)  # Print the most sold product

#  Calculate Average Order Value
average_order_value = total_sales / data['OrderID'].nunique()
# Explanation:
# 1. data['OrderID'].nunique() counts the number of unique orders
# 2. Divide total sales by number of orders to get the average order value
print("Average Order Value:", average_order_value)  # Print the average order value

#  Calculate Total Number of Unique Customers
unique_customers = data['Customer_ID'].nunique()  # Count unique customer IDs
print("Total Unique Customers:", unique_customers)  # Print the total number of unique customers
