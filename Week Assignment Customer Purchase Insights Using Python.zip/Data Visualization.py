import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load your dataset
# Example: df = pd.read_csv("sales_data.csv")
# Ensure columns: 'Product', 'Sales', 'Date', 'Country'

# Sample dataset
data = {
    'Product': ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K'],
    'Sales': [500, 700, 300, 900, 400, 600, 800, 200, 1000, 750, 450],
    'Date': pd.date_range(start='2025-01-01', periods=11, freq='M'),
    'Country': ['USA','UK','Germany','USA','UK','Germany','USA','France','USA','Germany','France']
}

# Create DataFrame
df = pd.DataFrame(data)

#  Bar chart: Top 10 products by sales
top_products = df.nlargest(10, 'Sales')  # top 10 products
plt.figure(figsize=(10,6))
sns.barplot(x='Product', y='Sales', data=top_products, palette='viridis')
plt.title('Top 10 Products by Sales')
plt.xlabel('Product')
plt.ylabel('Sales')
plt.show()

#  Line chart: Monthly sales trends 
# Convert 'Date' to datetime if not already
df['Date'] = pd.to_datetime(df['Date'])   # Ensure Date is datetime type
# Group sales by month and sum
monthly_sales = df.groupby(df['Date'].dt.to_period('M'))['Sales'].sum()
monthly_sales.index = monthly_sales.index.to_timestamp() # Convert PeriodIndex to Timestamp

plt.figure(figsize=(10,6))        # Set figure size
sns.lineplot(x=monthly_sales.index, y=monthly_sales.values, marker='o')
plt.title('Monthly Sales Trends')
plt.xlabel('Month')
plt.ylabel('Total Sales')
plt.xticks(rotation=45)
plt.show()

# Pie chart: Sales distribution by top 5 countries
country_sales = df.groupby('Country')['Sales'].sum().sort_values(ascending=False)
top_countries = country_sales.head(5)

plt.figure(figsize=(8,8))
plt.pie(top_countries, labels=top_countries.index, autopct='%1.1f%%', startangle=140, colors=sns.color_palette('Set2'))
plt.title('Sales Distribution by Top 5 Countries')
plt.show()
