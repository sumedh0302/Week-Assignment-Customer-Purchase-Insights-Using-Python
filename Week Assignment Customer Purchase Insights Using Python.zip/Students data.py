# Import the pandas library for data manipulation
import pandas as pd

# Load the dataset from a CSV file into a DataFrame called df
df = pd.read_csv("Students data.csv")

# Print the first 5 rows of the original dataset to see its structure
print("Original Data:")
print(df.head())

# Check for missing values in each column before handling
# isnull() returns True for NaN values, sum() counts them
print("\nMissing values before handling:")
print(df.isnull().sum())

# Handle missing values
# Fill missing values in 'Marks' column with the mean of the column
df['Marks'] = df['Marks'].fillna(df['Marks'].mean())

# Fill missing values in 'Quantity' column with the median of the column
df['Quantity'] = df['Quantity'].fillna(df['Quantity'].median())

# Fill missing values in 'UnitPrice' column with the median of the column
df['UnitPrice'] = df['UnitPrice'].fillna(df['UnitPrice'].median())

# Remove any duplicate rows from the DataFrame
df = df.drop_duplicates()

# Convert 'InvoiceDate' column to datetime format
# errors='coerce' will convert invalid dates to NaT
df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], errors='coerce')

# Create a new column 'TotalAmount' by multiplying 'Quantity' and 'UnitPrice'
df['TotalAmount'] = df['Quantity'] * df['UnitPrice']

# Print the first 5 rows of the cleaned DataFrame
print("\nCleaned Data:")
print(df.head())

# Optional: Check for missing values after cleaning
print("\nMissing values after handling:")
print(df.isnull().sum())
