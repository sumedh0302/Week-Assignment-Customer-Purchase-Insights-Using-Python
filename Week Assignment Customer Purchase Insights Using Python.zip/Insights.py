import pandas as pd  # Import pandas library for data manipulation

# Sample sales data stored in a dictionary
data = {
    "Product": ["A", "B", "C", "D", "E"],  # Product names
    "Sales": [1500, 1200, 900, 300, 600],  # Sales for each product
    "Month": ["December", "January", "December", "February", "December"],  # Month of sale
    "Region": ["Mumbai", "Delhi", "Mumbai", "Chennai", "Delhi"],  # Region of sale
    "Category": ["Electronics", "Electronics", "Clothing", "Clothing", "Electronics"]  # Product category
}

df = pd.DataFrame(data)  # Convert the dictionary into a pandas DataFrame for easier analysis

#  Find the top-selling product
top_product = df.groupby("Product")["Sales"].sum().idxmax()  # Group by Product, sum sales, get product with max sales
top_sales = df.groupby("Product")["Sales"].sum().max()       # Get the maximum sales value
total_sales = df["Sales"].sum()                              # Calculate total sales across all products

#  Find the month with the highest sales
top_month = df.groupby("Month")["Sales"].sum().idxmax()      # Group by Month, sum sales, get month with max sales

#  Find the low-performing product
low_product = df.groupby("Product")["Sales"].sum().idxmin()  # Group by Product, sum sales, get product with min sales

#  Find the region with the highest sales
top_region = df.groupby("Region")["Sales"].sum().idxmax()    # Group by Region, sum sales, get region with max sales

#  Find the top product category
top_category = df.groupby("Category")["Sales"].sum().idxmax() # Group by Category, sum sales, get category with max sales

# Generate the summary points
summary = [
    f"Top-selling product: Product {top_product}, contributing {top_sales/total_sales*100:.1f}% of total sales.",
    f"Month with highest sales: {top_month}, indicating seasonal trends.",
    f"Low-performing product: Product {low_product}, contributing {df.groupby('Product')['Sales'].sum()[low_product]/total_sales*100:.1f}% of sales.",
    f"Region with highest sales: {top_region}.",
    f"Top product category: {top_category}."
]

# Print each summary point
for point in summary:
    print(point)  # Display the insights
